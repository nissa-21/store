// NISSA - Tienda Online
const WHATSAPP_NUMBER = "541136620653";

const productsGrid = document.getElementById("products-grid");
const searchInput = document.getElementById("search-input");
const categories = document.querySelectorAll(".category");
const cart = document.getElementById("cart");
const openCart = document.getElementById("open-cart");
const closeCart = document.getElementById("close-cart");
const overlay = document.getElementById("overlay");
const cartItems = document.getElementById("cart-items");
const cartEmpty = document.getElementById("cart-empty");
const cartCount = document.getElementById("cart-count");
const cartTotal = document.getElementById("cart-total");
const clearCartButton = document.getElementById("clear-cart");
const checkoutButton = document.getElementById("checkout-button");
const menuButton = document.getElementById("menu-button");
const nav = document.getElementById("nav");

let selectedCategory = "todos";
let shoppingCart = JSON.parse(localStorage.getItem("nissaCart")) || [];

// Sincronizar el catálogo local desde el borrador guardado en el Panel Administrador
function reloadProductsFromStorage() {
  try {
    if (typeof localStorage !== "undefined") {
      const draft = localStorage.getItem("nissa_catalog_draft");
      if (draft) {
        const parsed = JSON.parse(draft);
        if (Array.isArray(parsed) && parsed.length > 0) {
          products = parsed;
          if (typeof window !== "undefined") {
            window.products = parsed;
          }
        }
      }
    }
  } catch (e) {}
}
reloadProductsFromStorage();

// Sincronizar el carrito local con los precios y datos más recientes definidos en products.js
function syncCartWithLatestProducts() {
  reloadProductsFromStorage();
  if (typeof products === "undefined" || !Array.isArray(products)) return;
  let changed = false;
  shoppingCart = shoppingCart.map(item => {
    const live = products.find(p => Number(p.id) === Number(item.id));
    if (!live) return item;
    changed = true;
    return {
      ...live,
      image: getProductImage(live),
      quantity: item.quantity
    };
  });
  if (changed) {
    saveCart();
  }
}
syncCartWithLatestProducts();

// Limpieza de estados anteriores de fotos cargadas desde UI para usar las fotos individuales
try {
  localStorage.removeItem("nissaProductImages");
} catch (e) {}

// Sincronizar caché rápida de imágenes desde localStorage (inmediata y síncrona)
window.NISSA_IMAGE_CACHE = window.NISSA_IMAGE_CACHE || {};
try {
  const quickMap = localStorage.getItem("nissa_image_map");
  if (quickMap) {
    const parsed = JSON.parse(quickMap);
    if (parsed && typeof parsed === "object") {
      Object.assign(window.NISSA_IMAGE_CACHE, parsed);
    }
  }
} catch (e) {}

// Carpeta donde se almacenan las fotos de los productos en GitHub
const PRODUCT_IMAGES_DIR = "fotos";

function getProductImage(product) {
  if (!product) return "";
  let img = product.image ? String(product.image).trim() : "";

  // Si no se asignó imagen explícita, buscar por nombre del producto normalizado (ej: "auriculares-bluetooth.jpg")
  if (!img && product.name) {
    img = product.name
      .toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") + ".jpg";
  }

  if (!img) return "";

  // Si es URL externa (http/https) o data URI, devolverla tal cual sin modificar
  if (/^(https?:|\/\/|data:)/i.test(img)) {
    return img;
  }

  // Limpiar cualquier prefijo de ruta para estandarizar
  img = img.replace(/^(\.\/|\/)+/, "");
  while (img.startsWith(PRODUCT_IMAGES_DIR + "/")) {
    img = img.substring((PRODUCT_IMAGES_DIR + "/").length);
  }

  // Verificar si la foto está en la caché de IndexedDB o memoria
  if (typeof window !== "undefined" && window.NISSA_IMAGE_CACHE) {
    if (window.NISSA_IMAGE_CACHE[img]) {
      return window.NISSA_IMAGE_CACHE[img];
    }
    // Probar sin extensión o con otras extensiones en caché
    const dot = img.lastIndexOf(".");
    const base = dot !== -1 ? img.substring(0, dot) : img;
    for (const ext of [".jpg", ".png", ".webp", ".jpeg"]) {
      if (window.NISSA_IMAGE_CACHE[base + ext]) {
        return window.NISSA_IMAGE_CACHE[base + ext];
      }
    }
  }

  // Retorna la ruta relativa './fotos/nombre.ext' compatible con GitHub Pages y local
  return `./${PRODUCT_IMAGES_DIR}/${img}`;
}

// Cargar imágenes guardadas desde IndexedDB para que se muestren en la tienda pública
(async function initStoreImageCache() {
  if (typeof window === "undefined" || !window.indexedDB) return;
  window.NISSA_IMAGE_CACHE = window.NISSA_IMAGE_CACHE || {};
  try {
    const req = indexedDB.open("nissa_images_db", 1);
    req.onsuccess = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("product_images")) return;
      const tx = db.transaction("product_images", "readonly");
      const getReq = tx.objectStore("product_images").getAll();
      getReq.onsuccess = () => {
        if (Array.isArray(getReq.result)) {
          let hasNew = false;
          getReq.result.forEach(item => {
            if (item && item.filename && item.dataUrl) {
              window.NISSA_IMAGE_CACHE[item.filename] = item.dataUrl;
              hasNew = true;
            }
          });
          if (hasNew) {
            // Re-renderizar la grilla de productos para que carguen de inmediato
            if (typeof renderProducts === "function") {
              renderProducts();
            }
            if (typeof currentModalProduct !== "undefined" && currentModalProduct && typeof renderProductModalContent === "function") {
              renderProductModalContent();
            }
          }
        }
      };
    };
  } catch (err) {
    console.warn("IndexedDB store cache warning:", err);
  }
})();

function handleProductImgError(img, productId) {
  if (!img) return;
  const currentSrc = img.getAttribute("src") || "";

  // Extraer el nombre del archivo sin ruta
  const filename = currentSrc.split("/").pop() || "";

  // Si la imagen está en la caché de IndexedDB o memoria, usarla de inmediato
  if (filename && typeof window !== "undefined" && window.NISSA_IMAGE_CACHE && window.NISSA_IMAGE_CACHE[filename]) {
    img.onerror = null;
    img.src = window.NISSA_IMAGE_CACHE[filename];
    img.style.display = "";
    if (img.nextElementSibling && img.nextElementSibling.style.display === "block") {
      img.nextElementSibling.style.display = "none";
    }
    return;
  }

  // Si la imagen es Base64 (data:) o URL externa, no intentar rutas de fotos/
  if (currentSrc.startsWith("data:") || currentSrc.startsWith("http://") || currentSrc.startsWith("https://") || currentSrc.startsWith("//")) {
    img.style.display = "none";
    if (img.nextElementSibling) {
      img.nextElementSibling.style.display = "block";
    }
    return;
  }

  const step = Number(img.dataset.retryStep || 0);
  const dotIndex = filename.lastIndexOf(".");
  const nameWithoutExt = dotIndex !== -1 ? filename.substring(0, dotIndex) : filename;
  const currentExt = dotIndex !== -1 ? filename.substring(dotIndex).toLowerCase() : ".jpg";

  // Intentar ubicaciones y extensiones alternativas (en raíz y en fotos/)
  const candidatePaths = [
    `./${nameWithoutExt}${currentExt}`,
    `./${PRODUCT_IMAGES_DIR}/${nameWithoutExt}${currentExt}`,
    `./${nameWithoutExt}.png`,
    `./${nameWithoutExt}.webp`,
    `./${PRODUCT_IMAGES_DIR}/${nameWithoutExt}.png`,
    `./${PRODUCT_IMAGES_DIR}/${nameWithoutExt}.webp`
  ].filter(p => !currentSrc.endsWith(p.replace(/^\.\//, "")));

  if (step < candidatePaths.length) {
    img.dataset.retryStep = String(step + 1);
    img.src = candidatePaths[step];
    return;
  }

  // Si fallan todas las rutas, ocultar imagen y mostrar emoji fallback limpio
  img.style.display = "none";
  if (img.parentElement && img.parentElement.classList.contains("pm-thumbnail-btn")) {
    img.parentElement.style.display = "none";
  } else if (img.nextElementSibling) {
    img.nextElementSibling.style.display = "block";
  }
}

function escapeAttr(value) {
  return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function parseNumericPrice(val) {
  if (typeof val === "number") return isNaN(val) ? 0 : val;
  if (!val) return 0;
  let s = String(val).trim().replace(/\$/g, "").trim();
  if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) {
    s = s.replace(/\./g, "").replace(",", ".");
  } else if (/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) {
    s = s.replace(/,/g, "");
  } else {
    s = s.replace(/,/g, ".");
  }
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}

function formatPrice(price) {
  const num = typeof price === "number" ? price : parseNumericPrice(price);
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(num);
}

function renderProductButtonHtml(productId, qty) {
  if (qty > 0) {
    return `
      <div class="product-qty-stepper" id="stepper-${productId}">
        <button type="button" class="stepper-btn stepper-btn-minus" onclick="changeCardQuantity(${productId}, -1)" aria-label="Restar una unidad">−</button>
        <div class="stepper-center">
          <span class="stepper-qty-num">${qty}</span>
          <span class="stepper-qty-label">${qty === 1 ? 'en carrito' : 'en carrito'}</span>
        </div>
        <button type="button" class="stepper-btn stepper-btn-plus" onclick="changeCardQuantity(${productId}, 1)" aria-label="Sumar una unidad">+</button>
      </div>
    `;
  }
  return `
    <button class="product-button" id="add-to-cart-btn-${productId}" onclick="addToCartFromCard(${productId})">
      Agregar al carrito
    </button>
  `;
}

function updateProductCardAction(productId) {
  const container = document.getElementById(`product-action-${productId}`);
  if (!container) return;
  const inCart = shoppingCart.find(item => Number(item.id) === Number(productId));
  const qty = inCart ? inCart.quantity : 0;
  container.innerHTML = renderProductButtonHtml(productId, qty);
}

function updateAllProductCardActions() {
  (typeof products !== "undefined" ? products : []).forEach(p => {
    updateProductCardAction(p.id);
  });
}

function renderProducts() {
  if (!productsGrid) return;
  const searchTerm = (searchInput ? searchInput.value : "").toLowerCase().trim();
  const filteredProducts = (typeof products !== "undefined" ? products : []).filter(product => {
    const matchesCategory = selectedCategory === "todos" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  productsGrid.innerHTML = "";

  filteredProducts.forEach(product => {
    const productCard = document.createElement("article");
    productCard.className = "product-card";
    productCard.id = `product-card-${product.id}`;

    // Clic en la tarjeta abre la página dedicada del producto
    productCard.onclick = (e) => {
      if (e.target.closest('.product-action-container') || e.target.closest('.product-qty-stepper') || e.target.closest('.product-button')) {
        return;
      }
      goToProductPage(product.id);
    };

    const imgSource = getProductImage(product);
    const isImagePath = imgSource && (imgSource.startsWith("data:image/") || imgSource.includes("/") || imgSource.includes("."));
    const photosList = getProductImagesList(product);

    const inCart = shoppingCart.find(item => Number(item.id) === Number(product.id));
    const qty = inCart ? inCart.quantity : 0;

    productCard.innerHTML = `
      ${product.tag ? `<span class="product-card-badge-top">${escapeAttr(product.tag)}</span>` : ''}
      ${photosList.length > 1 ? `<span class="product-card-photos-count">📷 ${photosList.length} fotos</span>` : ''}
      <div class="product-image">
        ${isImagePath ? `<img src="${escapeAttr(imgSource)}" alt="${escapeAttr(product.name)}" loading="lazy" onerror="handleProductImgError(this, ${product.id})"><span class="product-image-fallback" style="display:none;">📦</span>` : `<span class="product-image-fallback">${escapeAttr(imgSource || "📦")}</span>`}
      </div>
      <div class="product-content">
        <span class="product-category">${product.category}</span>
        <h3 class="product-name">${product.name}</h3>

        <div class="price-table" aria-label="Precios por cantidad">
          <div class="price-row main-price">
            <span class="price-from">Desde 1 u.</span>
            <strong>${formatPrice(product.price)}</strong>
          </div>
          <div class="price-row">
            <span class="price-from">Desde 3 u.</span>
            <strong>${formatPrice(product.price3 || product.price)}</strong>
          </div>
          <div class="price-row">
            <span class="price-from">Desde 5 u.</span>
            <strong>${formatPrice(product.price5 || product.price)}</strong>
          </div>
          <div class="price-row wholesale">
            <span class="price-from">+20 Mayor</span>
            <strong>${formatPrice(product.price20 || product.price)}</strong>
          </div>
        </div>

        <div class="product-view-hint">
          <span>Ver producto y comprar</span> ➔
        </div>

        <div class="product-action-container" id="product-action-${product.id}">
          ${renderProductButtonHtml(product.id, qty)}
        </div>
      </div>
    `;

    productsGrid.appendChild(productCard);
  });
}

function addToCartFromCard(productId) {
  const pId = Number(productId);
  const product = (typeof products !== "undefined" ? products : []).find(item => Number(item.id) === pId);
  if (!product) return;
  const existingProduct = shoppingCart.find(item => Number(item.id) === pId);

  if (existingProduct) existingProduct.quantity++;
  else shoppingCart.push({...product, image: getProductImage(product), quantity: 1});

  saveCart();
  renderCart();
  updateProductCardAction(productId);
}

function changeCardQuantity(productId, delta) {
  const pId = Number(productId);
  const product = (typeof products !== "undefined" ? products : []).find(item => Number(item.id) === pId);
  if (!product) return;
  const itemIndex = shoppingCart.findIndex(item => Number(item.id) === pId);

  if (itemIndex > -1) {
    shoppingCart[itemIndex].quantity += delta;
    if (shoppingCart[itemIndex].quantity <= 0) {
      shoppingCart.splice(itemIndex, 1);
    }
  } else if (delta > 0) {
    shoppingCart.push({...product, image: getProductImage(product), quantity: 1});
  }

  saveCart();
  renderCart();
  updateProductCardAction(productId);
}

function addToCart(productId) {
  addToCartFromCard(productId);
  openCartFunction();
}

function getUnitPrice(item) {
  const live = (typeof products !== "undefined" && Array.isArray(products))
    ? products.find(p => Number(p.id) === Number(item.id))
    : null;
  const target = live || item;
  return getUnitPriceForQty(target, item.quantity);
}

function getTierLabel(quantity) {
  if (quantity >= 20) return "Precio +20 u.";
  if (quantity >= 5) return "Precio x5 u.";
  if (quantity >= 3) return "Precio x3 u.";
  return "Precio x1 u.";
}

function renderCart() {
  const itemsContainer = document.getElementById("cart-items");
  const emptyContainer = document.getElementById("cart-empty");
  if (!itemsContainer || !emptyContainer) return;
  
  itemsContainer.innerHTML = "";
  const hasItems = shoppingCart.length > 0;

  if (hasItems) {
    emptyContainer.style.display = "none";
    emptyContainer.classList.add("hidden");
    itemsContainer.style.display = "block";
  } else {
    emptyContainer.style.display = "block";
    emptyContainer.classList.remove("hidden");
    itemsContainer.style.display = "none";
  }

  shoppingCart.forEach(item => {
    const unitPrice = getUnitPrice(item);
    const cartItem = document.createElement("div");
    cartItem.className = "cart-item";
    const imgSource = getProductImage(item);
    const isImagePath = imgSource && (imgSource.startsWith("data:image/") || imgSource.includes("/") || imgSource.includes("."));

    cartItem.innerHTML = `
      <div class="cart-item-image">
        ${isImagePath ? `<img src="${escapeAttr(imgSource)}" alt="${escapeAttr(item.name)}" onerror="handleProductImgError(this, ${item.id})"><span class="cart-image-fallback" style="display:none;">📦</span>` : `<span class="cart-image-fallback">${escapeAttr(imgSource || "📦")}</span>`}
      </div>
      <div class="cart-item-info">
        <h4>${item.name}</h4>
        <div class="cart-price-line">
          <p>${formatPrice(unitPrice)} <span>/ u.</span></p>
          <small>${getTierLabel(item.quantity)}</small>
        </div>
        <div class="cart-controls">
          <button class="qty-button" onclick="changeQuantity(${item.id}, -1)" aria-label="Reducir cantidad">−</button>
          <span class="qty-value">${item.quantity}</span>
          <button class="qty-button" onclick="changeQuantity(${item.id}, 1)" aria-label="Aumentar cantidad">+</button>
          <button class="remove-item" onclick="removeFromCart(${item.id})" aria-label="Eliminar producto">✕</button>
        </div>
        <div class="cart-subtotal">Subtotal <strong>${formatPrice(unitPrice * item.quantity)}</strong></div>
      </div>`;
    itemsContainer.appendChild(cartItem);
  });

  updateCartInfo();
}

function changeQuantity(productId, amount) {
  const product = shoppingCart.find(item => item.id === productId);
  if (!product) return;
  product.quantity += amount;
  if (product.quantity <= 0) return removeFromCart(productId);
  saveCart();
  renderCart();
}

function removeFromCart(productId) {
  shoppingCart = shoppingCart.filter(item => item.id !== productId);
  saveCart();
  renderCart();
}

function updateCartInfo() {
  const totalQuantity = shoppingCart.reduce((total, item) => total + item.quantity, 0);
  const totalPrice = shoppingCart.reduce((total, item) => total + getUnitPrice(item) * item.quantity, 0);
  if (cartCount) cartCount.textContent = totalQuantity;
  if (cartTotal) cartTotal.textContent = formatPrice(totalPrice);
  updateAllProductCardActions();
}

function saveCart() {
  localStorage.setItem("nissaCart", JSON.stringify(shoppingCart));
}

function clearCart() {
  shoppingCart = [];
  saveCart();
  renderCart();
}

if (clearCartButton) clearCartButton.addEventListener("click", clearCart);

function openCartFunction() {
  if (!cart || !overlay) return;
  cart.classList.add("active");
  overlay.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeCartFunction() {
  if (!cart || !overlay) return;
  cart.classList.remove("active");
  overlay.classList.remove("active");
  document.body.style.overflow = "";
}

if (openCart) openCart.addEventListener("click", openCartFunction);
if (closeCart) closeCart.addEventListener("click", closeCartFunction);
if (overlay) overlay.addEventListener("click", closeCartFunction);

categories.forEach(category => {
  category.addEventListener("click", () => {
    categories.forEach(button => button.classList.remove("active"));
    category.classList.add("active");
    selectedCategory = category.dataset.category;
    renderProducts();
  });
});

if (searchInput) searchInput.addEventListener("input", renderProducts);

if (checkoutButton) {
  checkoutButton.addEventListener("click", () => {
    if (shoppingCart.length === 0) return alert("Tu carrito está vacío. Agregá productos para continuar.");

    let message = "¡Hola NISSA! 👋 Quiero realizar el siguiente pedido desde la tienda online:\n\n";
    shoppingCart.forEach(item => {
      const unitPrice = getUnitPrice(item);
      message += `• *${item.name}*\n  Cantidad: ${item.quantity}\n  Precio unitario: ${formatPrice(unitPrice)} (${getTierLabel(item.quantity)})\n  Subtotal: ${formatPrice(unitPrice * item.quantity)}\n\n`;
    });

    const total = shoppingCart.reduce((sum, item) => sum + getUnitPrice(item) * item.quantity, 0);
    message += `💰 *TOTAL A ABONAR: ${formatPrice(total)}*\n\n`;
    message += "¿Tienen stock disponible para coordinar la entrega o retiro? ¡Muchas gracias!";

    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank");
  });
}

if (menuButton && nav) {
  menuButton.addEventListener("click", (e) => {
    e.stopPropagation();
    nav.classList.toggle("active");
  });
  document.querySelectorAll(".nav a").forEach(link => {
    link.addEventListener("click", (e) => {
      nav.classList.remove("active");
      const href = link.getAttribute("href");
      if (href && (href.includes("terminos") || href.includes("terminos-y-condiciones"))) {
        e.preventDefault();
        goToTermsPage();
      } else if (href && href.startsWith("#")) {
        goToMainPage(href);
      }
    });
  });
  document.addEventListener("click", (e) => {
    if (nav.classList.contains("active") && !nav.contains(e.target) && !menuButton.contains(e.target)) {
      nav.classList.remove("active");
    }
  });
}

// Navegar a la página o sección de Términos y Condiciones
function goToTermsPage() {
  const mainContent = document.getElementById("main-content");
  const terminosSection = document.getElementById("terminos-section");
  const productoSection = document.getElementById("producto-section");
  if (nav) nav.classList.remove("active");

  if (mainContent && terminosSection) {
    mainContent.style.display = "none";
    if (productoSection) productoSection.style.display = "none";
    terminosSection.style.display = "block";
    document.title = "Términos y Condiciones - NISSA";
    window.scrollTo({ top: 0, behavior: "smooth" });
    currentModalProduct = null;

    try {
      if (window.location.pathname !== "/terminos-y-condiciones") {
        window.history.pushState({ page: "terminos" }, "Términos y Condiciones - NISSA", "/terminos-y-condiciones");
      }
    } catch (e) {
      window.location.hash = "#terminos-y-condiciones";
    }
  } else {
    window.location.href = "/terminos-y-condiciones.html";
  }
}

// Navegar a la tienda / catálogo / página principal
function goToMainPage(targetHash) {
  const mainContent = document.getElementById("main-content");
  const terminosSection = document.getElementById("terminos-section");
  const productoSection = document.getElementById("producto-section");
  if (nav) nav.classList.remove("active");

  if (mainContent) {
    if (productoSection) productoSection.style.display = "none";
    if (terminosSection) terminosSection.style.display = "none";
    mainContent.style.display = "block";
    document.title = "NISSA - Tienda Online y Servicio Técnico";
    currentModalProduct = null;

    try {
      const cleanUrl = targetHash ? `/${targetHash}` : "/#inicio";
      window.history.pushState(null, "NISSA", cleanUrl);
    } catch (e) {
      window.location.hash = targetHash || "#inicio";
    }

    if (targetHash && targetHash !== "#" && targetHash !== "#inicio") {
      const targetEl = document.querySelector(targetHash);
      if (targetEl) {
        setTimeout(() => {
          targetEl.scrollIntoView({ behavior: "smooth" });
        }, 50);
      }
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  } else {
    window.location.href = `/${targetHash || "#inicio"}`;
  }
}

// Navegar a la página dedicada de un producto (página por separado que ocupa todo)
function goToProductPage(productId, updateUrl = true) {
  const pId = Number(productId);
  const p = (typeof products !== "undefined" ? products : []).find(item => Number(item.id) === pId);
  if (!p) return;

  currentModalProduct = p;
  currentModalImageIndex = 0;

  const inCart = shoppingCart.find(item => Number(item.id) === pId);
  currentModalQty = (inCart ? inCart.quantity : 1);

  const mainContent = document.getElementById("main-content");
  const terminosSection = document.getElementById("terminos-section");
  const productoSection = document.getElementById("producto-section");

  if (nav) nav.classList.remove("active");

  if (mainContent) mainContent.style.display = "none";
  if (terminosSection) terminosSection.style.display = "none";
  if (productoSection) productoSection.style.display = "block";

  renderProductModalContent();
  window.scrollTo({ top: 0, behavior: "instant" });

  if (updateUrl) {
    try {
      window.history.pushState({ productId: p.id }, `${p.name} - NISSA`, `/producto/${p.id}`);
      document.title = `${p.name} - Tienda NISSA`;
    } catch (e) {
      window.location.hash = `#producto-${p.id}`;
    }
  } else {
    document.title = `${p.name} - Tienda NISSA`;
  }
}

// Sincronización y manejo de rutas (URL directa, navegación, recarga)
function checkRoute() {
  const pathname = window.location.pathname || "";
  const hash = window.location.hash || "";
  const mainContent = document.getElementById("main-content");
  const terminosSection = document.getElementById("terminos-section");
  const productoSection = document.getElementById("producto-section");
  if (nav) nav.classList.remove("active");

  // 1. Verificar si la ruta es Términos y Condiciones
  const isTerms = pathname.includes("terminos") || hash.includes("terminos");
  if (isTerms) {
    if (mainContent) mainContent.style.display = "none";
    if (productoSection) productoSection.style.display = "none";
    if (terminosSection) terminosSection.style.display = "block";
    document.title = "Términos y Condiciones - NISSA";
    window.scrollTo(0, 0);
    currentModalProduct = null;
    return;
  }

  // 2. Verificar si la URL apunta directamente a un producto (/producto/1, ?producto=1, etc.)
  let prodId = null;
  const pathMatch = pathname.match(/\/producto\/([a-zA-Z0-9_-]+)/i);
  if (pathMatch && pathMatch[1]) {
    prodId = pathMatch[1];
  }

  if (!prodId) {
    const searchParams = new URLSearchParams(window.location.search);
    prodId = searchParams.get("producto") || searchParams.get("p") || searchParams.get("id");
  }

  if (!prodId && hash) {
    const hashMatch = hash.match(/#producto-?(\d+)/i) || hash.match(/#p-?(\d+)/i);
    if (hashMatch) {
      prodId = hashMatch[1];
    }
  }

  if (prodId) {
    const p = (typeof products !== "undefined" ? products : []).find(item => Number(item.id) === Number(prodId));
    if (p) {
      goToProductPage(p.id, false);
      return;
    }
  }

  // 3. De lo contrario, mostrar página principal
  if (productoSection) productoSection.style.display = "none";
  if (terminosSection) terminosSection.style.display = "none";
  if (mainContent) mainContent.style.display = "block";
  document.title = "NISSA - Tienda Online y Servicio Técnico";
  currentModalProduct = null;

  if (hash && hash !== "#" && hash !== "#inicio" && !hash.includes("producto")) {
    const targetEl = document.querySelector(hash);
    if (targetEl) {
      setTimeout(() => {
        targetEl.scrollIntoView({ behavior: "smooth" });
      }, 50);
    }
  }
}

window.addEventListener("hashchange", checkRoute);
window.addEventListener("popstate", checkRoute);
window.addEventListener("load", checkRoute);

const headerLogo = document.getElementById("header-logo");
if (headerLogo) {
  headerLogo.addEventListener("click", (e) => {
    e.preventDefault();
    goToMainPage("#inicio");
  });
}

// Exponer en window para llamadas inline
window.goToTermsPage = goToTermsPage;
window.goToMainPage = goToMainPage;

const yearSpan = document.getElementById("year");
if (yearSpan) yearSpan.textContent = new Date().getFullYear();

// ========================================================
// PRESENTACIÓN Y DETALLE DE PRODUCTO (MODAL INTERACTIVO)
// ========================================================
let currentModalProduct = null;
let currentModalImageIndex = 0;
let currentModalQty = 1;

function getProductImagesList(product) {
  if (!product) return [];
  if (Array.isArray(product.images) && product.images.length > 0) {
    return product.images;
  }
  if (product.image) {
    return [product.image];
  }
  return [];
}

function resolvePhotoUrl(imgName, product) {
  if (!imgName) return getProductImage(product);
  if (/^(https?:|\/\/|data:)/i.test(imgName)) return imgName;
  let clean = String(imgName).trim().replace(/^(\.\/|\/)+/, "");
  while (clean.startsWith(PRODUCT_IMAGES_DIR + "/")) {
    clean = clean.substring((PRODUCT_IMAGES_DIR + "/").length);
  }
  // Verificar si la foto está en la caché de IndexedDB o memoria
  if (typeof window !== "undefined" && window.NISSA_IMAGE_CACHE) {
    if (window.NISSA_IMAGE_CACHE[clean]) {
      return window.NISSA_IMAGE_CACHE[clean];
    }
    const dot = clean.lastIndexOf(".");
    const base = dot !== -1 ? clean.substring(0, dot) : clean;
    for (const ext of [".jpg", ".png", ".webp", ".jpeg"]) {
      if (window.NISSA_IMAGE_CACHE[base + ext]) {
        return window.NISSA_IMAGE_CACHE[base + ext];
      }
    }
  }
  return `./${PRODUCT_IMAGES_DIR}/${clean}`;
}

function getUnitPriceForQty(product, qty) {
  if (!product) return 0;
  const p = parseNumericPrice(product.price);
  const p3 = product.price3 !== undefined ? parseNumericPrice(product.price3) : p;
  const p5 = product.price5 !== undefined ? parseNumericPrice(product.price5) : p;
  const p20 = product.price20 !== undefined ? parseNumericPrice(product.price20) : p;

  if (qty >= 20) return p20;
  if (qty >= 5) return p5;
  if (qty >= 3) return p3;
  return p;
}

function getDiscountPercent(basePrice, discountedPrice) {
  if (!basePrice || !discountedPrice || discountedPrice >= basePrice) return 0;
  return Math.round(((basePrice - discountedPrice) / basePrice) * 100);
}

function handleModalSlideImgError(img, productId, originalFilename) {
  if (!img) return;
  const currentSrc = img.getAttribute("src") || "";

  if (currentSrc.startsWith("data:") || currentSrc.startsWith("http://") || currentSrc.startsWith("https://") || currentSrc.startsWith("//")) {
    img.style.display = "none";
    if (img.nextElementSibling && img.nextElementSibling.classList.contains("pm-main-image-fallback")) {
      img.nextElementSibling.style.display = "flex";
    }
    return;
  }

  const filename = currentSrc.split("/").pop() || originalFilename || "";

  // Revisar si está disponible en caché
  if (filename && typeof window !== "undefined" && window.NISSA_IMAGE_CACHE && window.NISSA_IMAGE_CACHE[filename]) {
    img.onerror = null;
    img.src = window.NISSA_IMAGE_CACHE[filename];
    img.style.display = "block";
    if (img.nextElementSibling && img.nextElementSibling.classList.contains("pm-main-image-fallback")) {
      img.nextElementSibling.style.display = "none";
    }
    return;
  }

  const step = Number(img.dataset.retryStep || 0);
  const dotIndex = filename.lastIndexOf(".");
  const nameWithoutExt = dotIndex !== -1 ? filename.substring(0, dotIndex) : filename;
  const currentExt = dotIndex !== -1 ? filename.substring(dotIndex).toLowerCase() : ".jpg";

  const candidateExtensions = [".jpg", ".png", ".jpeg", ".webp", ".JPG", ".PNG"];
  const alternateExts = candidateExtensions.filter(ext => ext.toLowerCase() !== currentExt.toLowerCase());

  if (step < alternateExts.length) {
    img.dataset.retryStep = String(step + 1);
    img.src = `./${PRODUCT_IMAGES_DIR}/${nameWithoutExt}${alternateExts[step]}`;
    return;
  }

  img.style.display = "none";
  if (img.nextElementSibling && img.nextElementSibling.classList.contains("pm-main-image-fallback")) {
    img.nextElementSibling.style.display = "flex";
  }
}

function handleModalThumbImgError(img, productId, originalFilename) {
  if (!img) return;
  const currentSrc = img.getAttribute("src") || "";

  if (currentSrc.startsWith("data:") || currentSrc.startsWith("http://") || currentSrc.startsWith("https://") || currentSrc.startsWith("//")) {
    img.style.display = "none";
    return;
  }

  const filename = currentSrc.split("/").pop() || originalFilename || "";

  // Revisar si está disponible en caché
  if (filename && typeof window !== "undefined" && window.NISSA_IMAGE_CACHE && window.NISSA_IMAGE_CACHE[filename]) {
    img.onerror = null;
    img.src = window.NISSA_IMAGE_CACHE[filename];
    img.style.display = "block";
    return;
  }

  const step = Number(img.dataset.retryStep || 0);
  const dotIndex = filename.lastIndexOf(".");
  const nameWithoutExt = dotIndex !== -1 ? filename.substring(0, dotIndex) : filename;
  const currentExt = dotIndex !== -1 ? filename.substring(dotIndex).toLowerCase() : ".jpg";

  const alternateExts = [".jpg", ".png", ".jpeg", ".webp", ".JPG", ".PNG"].filter(e => e.toLowerCase() !== currentExt.toLowerCase());
  if (step < alternateExts.length) {
    img.dataset.retryStep = String(step + 1);
    img.src = `./${PRODUCT_IMAGES_DIR}/${nameWithoutExt}${alternateExts[step]}`;
    return;
  }

  img.style.display = "none";
  if (img.parentElement && !img.parentElement.querySelector(".pm-thumb-fallback")) {
    const span = document.createElement("span");
    span.className = "pm-thumb-fallback";
    span.textContent = "📦";
    span.style.fontSize = "22px";
    img.parentElement.appendChild(span);
  }
}

function renderProductModalContent() {
  const container = document.getElementById("product-page-container") || document.getElementById("product-modal-container");
  if (!container || !currentModalProduct) return;
  const p = currentModalProduct;

  const images = getProductImagesList(p);
  if (currentModalImageIndex >= images.length) currentModalImageIndex = 0;
  if (currentModalImageIndex < 0) currentModalImageIndex = images.length - 1;

  const unitPrice = getUnitPriceForQty(p, currentModalQty);
  const subtotal = unitPrice * currentModalQty;
  const standardSubtotal = p.price * currentModalQty;
  const totalSavings = standardSubtotal - subtotal;

  const disc3 = getDiscountPercent(p.price, p.price3);
  const disc5 = getDiscountPercent(p.price, p.price5);
  const disc20 = getDiscountPercent(p.price, p.price20);

  // Generar HTML de miniaturas
  let thumbsHtml = "";
  if (images.length > 1) {
    thumbsHtml = `
      <div class="pm-thumbnails-strip" aria-label="Fotos del producto" id="pm-thumbnails-strip">
        ${images.map((img, idx) => {
          const thumbSrc = resolvePhotoUrl(img, p);
          const isActive = idx === currentModalImageIndex;
          return `
            <button type="button" class="pm-thumbnail-btn ${isActive ? 'active' : ''}" onclick="setModalImageIndex(${idx})" aria-label="Ver foto ${idx + 1}" data-thumb-index="${idx}">
              <img src="${escapeAttr(thumbSrc)}" alt="Miniatura ${idx + 1}" onerror="handleModalThumbImgError(this, ${p.id}, '${escapeAttr(img)}')">
            </button>
          `;
        }).join("")}
      </div>
    `;
  }

  // Generar viñetas de características esenciales y claras
  let featuresHtml = "";
  if (Array.isArray(p.features) && p.features.length > 0) {
    featuresHtml = `
      <div class="pm-features-box">
        <div class="pm-section-label">✨ Características destacadas</div>
        <ul class="pm-features-list">
          ${p.features.slice(0, 4).map(f => `
            <li>
              <span class="pm-feature-check">✓</span>
              <span>${escapeAttr(f)}</span>
            </li>
          `).join("")}
        </ul>
      </div>
    `;
  }

  // Mensaje de WhatsApp personalizado
  const waText = encodeURIComponent(
    `¡Hola NISSA! 👋 Me interesa comprar ${currentModalQty} u. de "${p.name}" por ${formatPrice(subtotal)} (${getTierLabel(currentModalQty)}).\n\n¿Tienen stock disponible para retiro o entrega en el día? ¡Muchas gracias!`
  );

  container.innerHTML = `
    <!-- BARRA SUPERIOR DE NAVEGACIÓN Y MIGAS DE PAN (TIENDA REAL) -->
    <div class="product-page-nav-bar">
      <button type="button" class="product-page-back-link" onclick="goToMainPage('#productos')">
        ← Volver a la tienda
      </button>
      <div class="product-breadcrumbs">
        <a onclick="goToMainPage('#inicio')">Inicio</a>
        <span class="crumb-sep">/</span>
        <a onclick="goToMainPage('#productos')">Tienda</a>
        <span class="crumb-sep">/</span>
        <span class="crumb-current">${escapeAttr(p.name)}</span>
      </div>
    </div>

    <!-- CUERPO PRINCIPAL DEL PRODUCTO (DOS COLUMNAS) -->
    <div class="pm-body-grid">
      
      <!-- COLUMNA IZQUIERDA: CARRUSEL DESPLAZABLE DE FOTOS -->
      <div class="pm-gallery-col">
        <div class="pm-main-image-wrap" id="pm-carousel-wrap">
          ${p.tag ? `<span class="pm-gallery-badge-tag">${escapeAttr(p.tag)}</span>` : ''}
          ${images.length > 1 ? `<span class="pm-gallery-counter" id="pm-counter">📷 Foto ${currentModalImageIndex + 1} de ${images.length}</span>` : ''}

          ${images.length > 1 ? `
            <button type="button" class="pm-gallery-arrow pm-gallery-arrow-prev" onclick="prevModalImage(event)" aria-label="Foto anterior">‹</button>
            <button type="button" class="pm-gallery-arrow pm-gallery-arrow-next" onclick="nextModalImage(event)" aria-label="Foto siguiente">›</button>
          ` : ''}

          <div class="pm-carousel-track" id="pm-carousel-track" style="transform: translateX(-${currentModalImageIndex * 100}%);">
            ${images.map((imgFile, idx) => {
              const imgSrc = resolvePhotoUrl(imgFile, p);
              return `
                <div class="pm-carousel-slide" data-slide-index="${idx}">
                  <img src="${escapeAttr(imgSrc)}" alt="${escapeAttr(p.name)} - Foto ${idx + 1}" class="pm-slide-img" onerror="handleModalSlideImgError(this, ${p.id}, '${escapeAttr(imgFile)}')">
                  <span class="pm-main-image-fallback" style="display:none;">📦</span>
                </div>
              `;
            }).join('')}
          </div>

          ${images.length > 1 ? `
            <div class="pm-carousel-dots" id="pm-dots">
              ${images.map((_, idx) => `
                <button type="button" class="pm-dot ${idx === currentModalImageIndex ? 'active' : ''}" onclick="setModalImageIndex(${idx})" aria-label="Ir a foto ${idx + 1}"></button>
              `).join('')}
            </div>
          ` : ''}
        </div>

        ${thumbsHtml}
      </div>

      <!-- COLUMNA DERECHA: INFORMACIÓN, PRECIOS Y COMPRA -->
      <div class="pm-info-col">
        <div class="pm-meta-row">
          <span class="pm-category-pill">${escapeAttr(p.category)}</span>
          <span class="pm-stock-pill"><b></b> En stock inmediato para entrega o retiro</span>
        </div>

        <h1 class="pm-product-title">${escapeAttr(p.name)}</h1>

        <div class="product-rating-line">
          <span class="product-rating-stars">★★★★★</span>
          <span>4.9 · Calificaciones verificadas NISSA</span>
        </div>

        <p class="pm-description">${escapeAttr(p.description || "")}</p>

        <!-- TARJETA DE PRECIOS Y DESCUENTOS POR VOLUMEN -->
        <div class="pm-pricing-card">
          <div class="pm-pricing-header">
            <div class="pm-pricing-unit-col">
              <span class="pm-pricing-label">Precio Unitario:</span>
              <div class="pm-pricing-unit-line">
                <span class="pm-pricing-main-value" id="pm-price-display">${formatPrice(unitPrice)}</span>
                <span class="pm-pricing-unit-tag">/ unidad</span>
              </div>
            </div>
            <div class="pm-pricing-subtotal-col">
              <span class="pm-pricing-label">Subtotal (${currentModalQty} u.):</span>
              <div class="pm-pricing-subtotal-val" id="pm-subtotal-display">
                ${formatPrice(subtotal)}
              </div>
            </div>
          </div>

          <!-- ESCALONES DE VOLUMEN (CLICABLES) -->
          <div>
            <div style="font-size:11px; font-weight:800; color:#475569; text-transform:uppercase; margin-bottom:6px; letter-spacing:0.04em;">
              💡 Descuentos por cantidad:
            </div>
            <div class="pm-tiers-grid">
              <button type="button" class="pm-tier-btn ${currentModalQty < 3 ? 'active' : ''}" onclick="setModalQty(1)" title="Seleccionar 1 unidad">
                <span class="pm-tier-qty">1 u.</span>
                <span class="pm-tier-price">${formatPrice(p.price)}</span>
                <span class="pm-tier-badge">Lista</span>
              </button>

              <button type="button" class="pm-tier-btn ${currentModalQty >= 3 && currentModalQty < 5 ? 'active' : ''}" onclick="setModalQty(3)" title="Seleccionar 3 unidades">
                <span class="pm-tier-qty">Desde 3 u.</span>
                <span class="pm-tier-price">${formatPrice(p.price3 || p.price)}</span>
                <span class="pm-tier-badge">${disc3 > 0 ? `-${disc3}%` : 'Ahorro'}</span>
              </button>

              <button type="button" class="pm-tier-btn ${currentModalQty >= 5 && currentModalQty < 20 ? 'active' : ''}" onclick="setModalQty(5)" title="Seleccionar 5 unidades">
                <span class="pm-tier-qty">Desde 5 u.</span>
                <span class="pm-tier-price">${formatPrice(p.price5 || p.price)}</span>
                <span class="pm-tier-badge">${disc5 > 0 ? `-${disc5}%` : 'Ahorro'}</span>
              </button>

              <button type="button" class="pm-tier-btn wholesale ${currentModalQty >= 20 ? 'active' : ''}" onclick="setModalQty(20)" title="Seleccionar 20 unidades mayoristas">
                <span class="pm-tier-qty">+20 Mayor</span>
                <span class="pm-tier-price">${formatPrice(p.price20 || p.price)}</span>
                <span class="pm-tier-badge">${disc20 > 0 ? `-${disc20}%` : 'Mayor'}</span>
              </button>
            </div>
          </div>

          <!-- BANNER DE AHORRO DINÁMICO -->
          <div id="pm-savings-container">
            ${totalSavings > 0 ? `
              <div class="pm-savings-box">
                <span class="pm-savings-icon">🎉</span>
                <span>¡Descuento activo! Ahorrás <strong>${formatPrice(totalSavings)}</strong> en tu compra.</span>
              </div>
            ` : `
              <div style="font-size:11.5px; color:#64748b; background:#ffffff; border:1px dashed #cbd5e1; border-radius:10px; padding:8px 12px; text-align:center;">
                ⚡ Llevando <strong>3 unidades o más</strong> accedés a precios con descuento.
              </div>
            `}
          </div>
        </div>

        <!-- ACCIONES DE COMPRA -->
        <div class="pm-actions-row">
          <div class="pm-stepper">
            <button type="button" class="pm-stepper-btn" onclick="changeModalQty(-1)" aria-label="Restar una unidad">−</button>
            <span class="pm-stepper-value" id="pm-stepper-num">${currentModalQty}</span>
            <button type="button" class="pm-stepper-btn" onclick="changeModalQty(1)" aria-label="Sumar una unidad">+</button>
          </div>

          <button type="button" class="pm-btn-add-cart" id="pm-add-cart-btn" onclick="addModalProductToCart()">
            <span>🛒 Agregar al Carrito</span>
            <span style="font-size:12px; opacity:0.9;">(${formatPrice(subtotal)})</span>
          </button>
        </div>

        <!-- BOTÓN DIRECTO DE WHATSAPP -->
        <a href="https://wa.me/${WHATSAPP_NUMBER}?text=${waText}" target="_blank" rel="noopener" class="pm-btn-whatsapp">
          <svg viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 11.966.01c3.179.001 6.169 1.24 8.409 3.485 2.24 2.246 3.473 5.239 3.471 8.417-.004 6.616-5.34 11.954-11.91 11.954a11.91 11.91 0 0 1-5.69-1.444L0 24zm5.824-3.482l.415.247a9.92 9.92 0 0 0 5.174 1.456c5.825 0 10.563-4.73 10.567-10.548.002-2.822-1.096-5.474-3.09-7.472-1.995-2-4.65-3.1-7.468-3.102-5.83 0-10.57 4.73-10.574 10.551a10.5 10.5 0 0 0 1.426 5.142l.271.431-1.01 3.687 3.791-.995z"/></svg>
          <span>Consultar o pedir por WhatsApp</span>
        </a>

        <!-- CARACTERÍSTICAS DESTACADAS -->
        ${featuresHtml}

      </div>
    </div>
  `;

  // Inicializar gestos táctiles de desplazamiento (swipe) en celulares y tablets
  initModalCarouselGestures();
}

function initModalCarouselGestures() {
  const wrap = document.getElementById("pm-carousel-wrap");
  const track = document.getElementById("pm-carousel-track");
  if (!wrap || !track) return;

  let startX = 0;
  let startY = 0;
  let currentDiffX = 0;
  let isSwiping = false;
  let isHorizontal = false;

  wrap.addEventListener("touchstart", (e) => {
    if (!e.touches || e.touches.length !== 1) return;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
    currentDiffX = 0;
    isSwiping = true;
    isHorizontal = false;
    track.style.transition = "none";
  }, { passive: true });

  wrap.addEventListener("touchmove", (e) => {
    if (!isSwiping || !e.touches || e.touches.length !== 1) return;
    const diffX = e.touches[0].clientX - startX;
    const diffY = e.touches[0].clientY - startY;

    if (!isHorizontal) {
      if (Math.abs(diffX) > 10 || Math.abs(diffY) > 10) {
        if (Math.abs(diffX) > Math.abs(diffY)) {
          isHorizontal = true;
        } else {
          // Es un scroll vertical de la página: cancelar swipe
          isSwiping = false;
          track.style.transition = "transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)";
          track.style.transform = `translateX(-${currentModalImageIndex * 100}%)`;
          return;
        }
      }
    }

    if (isHorizontal) {
      if (e.cancelable) e.preventDefault();
      currentDiffX = diffX;
      // Desplazamiento dinámico continuo bajo el dedo
      track.style.transform = `translateX(calc(-${currentModalImageIndex * 100}% + ${diffX}px))`;
    }
  }, { passive: false });

  const handleGestureEnd = () => {
    if (!isSwiping) return;
    isSwiping = false;
    track.style.transition = "transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)";

    if (isHorizontal && Math.abs(currentDiffX) > 35) {
      if (currentDiffX < 0) {
        nextModalImage();
      } else {
        prevModalImage();
      }
    } else {
      // Revertir a la diapositiva actual
      track.style.transform = `translateX(-${currentModalImageIndex * 100}%)`;
    }

    isHorizontal = false;
    currentDiffX = 0;
  };

  wrap.addEventListener("touchend", handleGestureEnd, { passive: true });
  wrap.addEventListener("touchcancel", handleGestureEnd, { passive: true });
}

function setModalImageIndex(idx) {
  if (!currentModalProduct) return;
  const images = getProductImagesList(currentModalProduct);
  if (!images || images.length === 0) return;

  // Manejo de índice circular (permite ir de la última a la primera y viceversa)
  const total = images.length;
  idx = ((idx % total) + total) % total;
  currentModalImageIndex = idx;

  const track = document.getElementById("pm-carousel-track");
  if (track) {
    track.style.transition = "transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)";
    track.style.transform = `translateX(-${currentModalImageIndex * 100}%)`;
  }

  // Actualizar clase activa en miniaturas y desplazarlas suavemente a la vista
  const thumbs = document.querySelectorAll(".pm-thumbnail-btn");
  thumbs.forEach((t, i) => {
    if (i === currentModalImageIndex) {
      t.classList.add("active");
      try {
        t.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      } catch (err) {}
    } else {
      t.classList.remove("active");
    }
  });

  // Actualizar puntos de navegación (dots)
  const dots = document.querySelectorAll(".pm-dot");
  dots.forEach((d, i) => {
    if (i === currentModalImageIndex) d.classList.add("active");
    else d.classList.remove("active");
  });

  // Actualizar contador numérico
  const counter = document.getElementById("pm-counter");
  if (counter) {
    counter.textContent = `📷 Foto ${currentModalImageIndex + 1} de ${total}`;
  }
}

function prevModalImage(e) {
  if (e) {
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();
  }
  if (!currentModalProduct) return;
  const images = getProductImagesList(currentModalProduct);
  if (images.length <= 1) return;
  setModalImageIndex(currentModalImageIndex - 1);
}

function nextModalImage(e) {
  if (e) {
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();
  }
  if (!currentModalProduct) return;
  const images = getProductImagesList(currentModalProduct);
  if (images.length <= 1) return;
  setModalImageIndex(currentModalImageIndex + 1);
}

function changeModalQty(delta) {
  setModalQty(currentModalQty + delta);
}

function setModalQty(newQty) {
  currentModalQty = Math.max(1, newQty);
  updateModalPricingUI();
}

function updateModalPricingUI() {
  if (!currentModalProduct) return;
  const p = currentModalProduct;
  const unitPrice = getUnitPriceForQty(p, currentModalQty);
  const subtotal = unitPrice * currentModalQty;
  const standardSubtotal = p.price * currentModalQty;
  const totalSavings = standardSubtotal - subtotal;

  const priceDisp = document.getElementById("pm-price-display");
  if (priceDisp) priceDisp.textContent = formatPrice(unitPrice);

  const subtotalDisp = document.getElementById("pm-subtotal-display");
  if (subtotalDisp) subtotalDisp.textContent = formatPrice(subtotal);

  const stepperNum = document.getElementById("pm-stepper-num");
  if (stepperNum) stepperNum.textContent = currentModalQty;

  const addBtn = document.getElementById("pm-add-cart-btn");
  if (addBtn && !addBtn.classList.contains("added")) {
    addBtn.innerHTML = `<span>🛒 Agregar al Carrito</span><span style="font-size:12px; opacity:0.9;">(${formatPrice(subtotal)})</span>`;
  }

  const tierBtns = document.querySelectorAll(".pm-tier-btn");
  if (tierBtns.length === 4) {
    tierBtns[0].classList.toggle("active", currentModalQty < 3);
    tierBtns[1].classList.toggle("active", currentModalQty >= 3 && currentModalQty < 5);
    tierBtns[2].classList.toggle("active", currentModalQty >= 5 && currentModalQty < 20);
    tierBtns[3].classList.toggle("active", currentModalQty >= 20);
  }

  const savingsBox = document.getElementById("pm-savings-container");
  if (savingsBox) {
    if (totalSavings > 0) {
      savingsBox.innerHTML = `
        <div class="pm-savings-box">
          <span class="pm-savings-icon">🎉</span>
          <span>¡Descuento activo! Ahorrás <strong>${formatPrice(totalSavings)}</strong> en tu compra.</span>
        </div>
      `;
    } else {
      savingsBox.innerHTML = `
        <div style="font-size:11.5px; color:#64748b; background:#ffffff; border:1px dashed #cbd5e1; border-radius:10px; padding:8px 12px; text-align:center;">
          ⚡ Llevando <strong>3 unidades o más</strong> accedés a precios con descuento.
        </div>
      `;
    }
  }

  const waBtn = document.querySelector(".pm-btn-whatsapp");
  if (waBtn) {
    const waText = encodeURIComponent(
      `¡Hola NISSA! 👋 Me interesa comprar ${currentModalQty} u. de "${p.name}" por ${formatPrice(subtotal)} (${getTierLabel(currentModalQty)}).\n\n¿Tienen stock disponible para retiro o entrega en el día? ¡Muchas gracias!`
    );
    waBtn.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${waText}`;
  }
}

function addModalProductToCart() {
  if (!currentModalProduct) return;
  const p = currentModalProduct;
  const existingProduct = shoppingCart.find(item => Number(item.id) === Number(p.id));

  if (existingProduct) {
    existingProduct.quantity = currentModalQty;
  } else {
    shoppingCart.push({
      ...p,
      image: getProductImage(p),
      quantity: currentModalQty
    });
  }

  saveCart();
  renderCart();
  updateProductCardAction(p.id);

  const addBtn = document.getElementById("pm-add-cart-btn");
  if (addBtn) {
    addBtn.classList.add("added");
    addBtn.innerHTML = `<span>✓ ¡Agregado al carrito!</span>`;
    setTimeout(() => {
      if (document.getElementById("pm-add-cart-btn")) {
        renderProductModalContent();
      }
    }, 1200);
  }
}
// Atajos de teclado: Escape vuelve a la tienda si se está en la página de un producto
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    const productoSection = document.getElementById("producto-section");
    if (productoSection && productoSection.style.display !== "none") {
      goToMainPage("#productos");
    }
  }
});

// Asignar funciones globales para compatibilidad y uso inline
window.goToProductPage = goToProductPage;
window.openProductModal = goToProductPage;
window.closeProductModal = () => goToMainPage("#productos");
window.goToMainPage = goToMainPage;
window.goToTermsPage = goToTermsPage;
window.checkRoute = checkRoute;
window.setModalImageIndex = setModalImageIndex;
window.prevModalImage = prevModalImage;
window.nextModalImage = nextModalImage;
window.changeModalQty = changeModalQty;
window.setModalQty = setModalQty;
window.addModalProductToCart = addModalProductToCart;

// Escuchar cambios de almacenamiento y eventos de actualización del Panel Administrador
function handleCatalogLiveUpdate() {
  reloadProductsFromStorage();
  syncCartWithLatestProducts();
  renderProducts();
  if (currentModalProduct) {
    const updated = (typeof products !== "undefined" ? products : []).find(p => Number(p.id) === Number(currentModalProduct.id));
    if (updated) {
      currentModalProduct = updated;
      renderProductModalContent();
    }
  }
}

window.addEventListener("storage", (e) => {
  if (e.key === "nissa_catalog_draft" || e.key === "nissaProductImages") {
    handleCatalogLiveUpdate();
  }
});
window.addEventListener("nissa_catalog_updated", handleCatalogLiveUpdate);
window.addEventListener("focus", handleCatalogLiveUpdate);

// Inicialización de la aplicación y comprobación de URL inicial
document.addEventListener("DOMContentLoaded", () => {
  reloadProductsFromStorage();
  syncCartWithLatestProducts();
  renderProducts();
  renderCart();
  checkRoute();
});
reloadProductsFromStorage();
syncCartWithLatestProducts();
renderProducts();
renderCart();
checkRoute();
